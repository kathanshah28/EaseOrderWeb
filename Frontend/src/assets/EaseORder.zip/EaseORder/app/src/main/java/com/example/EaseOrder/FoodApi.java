package com.example.EaseOrder;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface FoodApi {
    @GET("/api/v1/food/food_list")
    Call<ArrayList<FoodInfo>> getFoodList();
}
