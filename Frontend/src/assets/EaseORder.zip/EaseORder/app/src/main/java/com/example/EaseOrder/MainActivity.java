package com.example.EaseOrder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    FoodRecycleViewAdapter foodRecycleViewAdapter;
    ArrayList<FoodInfo> arrinfo = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView Recycle = findViewById(R.id.Recycle);
        Recycle.setLayoutManager(new LinearLayoutManager(this));
        String url = "http://localhost:4000/api/v1/food/food_list"; //GET

        foodRecycleViewAdapter = new FoodRecycleViewAdapter(MainActivity.this,arrinfo);
        Recycle.setAdapter(foodRecycleViewAdapter);

        fetchFoodList();
    }

    private void fetchFoodList() {
        // Retrofit code to fetch food list and update foodList ArrayList
        // This code should be similar to the Retrofit code provided earlier
        // After fetching data, update foodList and notify adapter
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.0.5:4000")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        FoodApi foodApi = retrofit.create(FoodApi.class);

        Call<ArrayList<FoodInfo>> call = foodApi.getFoodList();
        call.enqueue(new Callback<ArrayList<FoodInfo>>() {
            @Override
            public void onResponse(Call<ArrayList<FoodInfo>> call, Response<ArrayList<FoodInfo>> response) {
                if (response.isSuccessful()) {
                    // Handle successful response
                    arrinfo.clear(); // Clear existing data
                    arrinfo.addAll(response.body()); // Add new data
                    foodRecycleViewAdapter.notifyDataSetChanged(); // Notify adapter of data set change
                } else {
                    // Handle error response
                }
            }

            @Override
            public void onFailure(Call<ArrayList<FoodInfo>> call, Throwable t) {
                // Handle network failure
            }
        });
    }
}