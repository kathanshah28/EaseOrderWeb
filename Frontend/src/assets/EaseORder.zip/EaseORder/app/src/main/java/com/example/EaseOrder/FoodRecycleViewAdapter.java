package com.example.EaseOrder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FoodRecycleViewAdapter extends RecyclerView.Adapter<FoodRecycleViewAdapter.ViewHolder>{
    private int lastPosition;

    Context context; // context for the given file

    ArrayList<FoodInfo> arrifo; //Arr for Personinfo items

    public FoodRecycleViewAdapter(Context context, ArrayList<FoodInfo> arrinfo){
        this.context = context; //passing value of the other class context to this constructor
        this.arrifo = arrinfo; //passing value of ArrayList for which Recycler view you want to create
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.foodlist,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.fname.setText(arrifo.get(position).fname);
        holder.fdesc.setText(arrifo.get(position).fdesc);
        holder.fprice.setText(arrifo.get(position).fprice);
        holder.fcategory.setText(arrifo.get(position).fcategory);

        Picasso.get().load(arrifo.get(position).fimgurl).into(holder.fimg);

        animation(holder.itemView,position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView fname,fdesc,fprice,fcategory;
        ImageView fimg;
        LinearLayout infoLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            //getting all ids for runtime adding
            fname = itemView.findViewById(R.id.fname);
            fdesc = itemView.findViewById(R.id.fdesc);
            fprice = itemView.findViewById(R.id.fprice);
            fcategory = itemView.findViewById(R.id.fcategory);
            fimg = itemView.findViewById(R.id.foodimage);
            infoLayout = itemView.findViewById(R.id.infoLayout); //for Animation purpose
        }
    }

    @Override
    public int getItemCount() {
        int size = arrifo.size();
        return size;
    }
    public void animation(View animView,int position){
        if(position>lastPosition){
            Animation anImate = AnimationUtils.loadAnimation(context, R.anim.lay_anim);
            animView.startAnimation(anImate);
            lastPosition = position;
        }
    }
}
